package webservice;


public interface AdeersWebService {

	public String callWebService(String xml) throws Exception;
}
