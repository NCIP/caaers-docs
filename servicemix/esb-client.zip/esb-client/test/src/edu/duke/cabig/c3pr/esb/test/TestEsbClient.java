package edu.duke.cabig.c3pr.esb.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.io.StringReader;
import java.util.List;
import java.util.Vector;

import junit.framework.TestCase;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQQueue;
import org.jdom.Element;
import org.jdom.Namespace;
import org.jdom.input.SAXBuilder;

import edu.duke.cabig.caaers.esb.BroadcastException;
import edu.duke.cabig.caaers.esb.MessageBroadcastServiceImpl;


public class TestEsbClient extends TestCase {
    public static String brokerUrl="tcp://localhost:61616";
    private String fileName= "/Users/sakkala/tech/adeers/new-schemas/expeditedAdverseEventReport-221.xml";
    //public static String brokerUrl="tcp://duke.semanticbits.com:62618";
    public static String sendQueue="adeers-ae-message.inputQueue";
    public static String resultQueue="adeers-ae-message.outputQueue";
    public static long sleep=5000;
    
    public void setUp() throws Exception{
    	super.setUp();
    }


    public void testSampleMessage(){
        MessageBroadcastServiceImpl esbClient=new MessageBroadcastServiceImpl();

            


            System.out.println("using broker at " + brokerUrl);

            try {
                esbClient.setConnectionFactory(new ActiveMQConnectionFactory(brokerUrl));
                esbClient.setSendQueue(new ActiveMQQueue(sendQueue));
                esbClient.setResultQueue(new ActiveMQQueue(resultQueue));
                esbClient.initialize();


                //System.out.println("XML Payload....");
                String xml="";
                File f= new File(fileName);
                //System.out.println(f.getAbsolutePath());
                BufferedReader fr=new BufferedReader(new FileReader(f));
                String temp="";
                while((temp=fr.readLine())!=null){
                    xml+=temp;
                    //System.out.println(temp);
                }
                
                StringBuilder sb = new StringBuilder();
                sb.append("<EXTERNAL_SYSTEMS>https://capps-ctep.nci.nih.gov/adeersws10gbeta/services/AEReportXMLService::ADEERSBETA::testadeers1#</EXTERNAL_SYSTEMS>");
                sb.append("<REPORT_ID>221</REPORT_ID>");
                sb.append("<SUBMITTER_EMAIL>test@test.edu</SUBMITTER_EMAIL>");
                //if there are external systems, send message via service mix
            	xml = xml.replaceAll("<AdverseEventReport>", "<AdverseEventReport>" + sb.toString());
            	
                esbClient.broadcast(xml);
                System.out.println("Sleeping for"+sleep);
                Thread.sleep(sleep);
                System.out.println("out of sleep..");
                Vector result = esbClient.getBroadcastStatus();
                String msg = "";
                if(result!=null){
                    for(int i=0 ; i<result.size();i++){
                        msg=(String)result.get(i);
                        System.out.println((i+1)+".");
                        System.out.println(msg);
                        System.out.println("--------");
                    }
                
                
                
                    SAXBuilder saxBuilder=new SAXBuilder("org.apache.xerces.parsers.SAXParser");
                    Reader stringReader=new StringReader(msg);

        			org.jdom.Document jdomDocument=saxBuilder.build(stringReader);
        			org.jdom.Element root = jdomDocument.getRootElement();
        			
        			Element body = root.getChild("Body",root.getNamespace());
        			//System.out.println(((Element)body.getChildren().get(0)).getName());
        			Namespace n1 = ((Element)body.getChildren().get(0)).getNamespace();
        			Element response = body.getChild("submitAEDataXMLAsAttachmentResponse",n1);
        			Namespace n = ((Element)response.getChildren().get(0)).getNamespace();
        			Element jobInfo = response.getChild("AEReportJobInfo",n);
        			String status = jobInfo.getChild("reportStatus").getValue();
        			//exceptions
        			List<Element> exceptions = jobInfo.getChildren("jobExceptions");
        			
        			for (Element exception:exceptions) {
        				System.out.println(exception.getChild("code").getValue());
        				System.out.println(exception.getChild("description").getValue());
        			}

        			assertEquals (status,"SUCCESS") ; 
                }else{
                    System.out.println("no avalbale result..");
                }

            } catch (BroadcastException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }finally{
                try {
                    esbClient.close();
                } catch (BroadcastException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }

    }
}
