package edu.duke.cabig.caaers.esb;

public interface ESBMessageConsumer {
	public void processMessage(String message);
}
