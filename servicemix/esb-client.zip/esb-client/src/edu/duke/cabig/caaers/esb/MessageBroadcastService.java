package edu.duke.cabig.caaers.esb;

import java.util.Vector;

import edu.duke.cabig.caaers.esb.BroadcastException;


public interface MessageBroadcastService {
	
	public void broadcast(String message) throws BroadcastException;
	
	public Vector getBroadcastStatus();

}
