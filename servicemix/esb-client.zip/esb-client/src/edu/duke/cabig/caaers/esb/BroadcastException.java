package edu.duke.cabig.caaers.esb;

public class BroadcastException extends java.lang.Exception{


    public BroadcastException() {
        super();    //To change body of overridden methods use File | Settings | File Templates.
    }

    public BroadcastException(String string) {
        super(string);    //To change body of overridden methods use File | Settings | File Templates.
    }

    public BroadcastException(String string, Throwable throwable) {
        super(string, throwable);    //To change body of overridden methods use File | Settings | File Templates.
    }

    public BroadcastException(Throwable throwable) {
        super(throwable);    //To change body of overridden methods use File | Settings | File Templates.
    }
}
