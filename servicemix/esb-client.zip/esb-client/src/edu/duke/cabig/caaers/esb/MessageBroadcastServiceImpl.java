package edu.duke.cabig.caaers.esb;

import java.util.Vector;

import javax.jms.ConnectionFactory;
import javax.jms.Destination;

import edu.duke.cabig.caaers.esb.BroadcastException;
import edu.duke.cabig.caaers.esb.JmsService;



public class MessageBroadcastServiceImpl extends JmsService implements MessageBroadcastService{

	public void broadcast(String message) throws BroadcastException {
		// TODO Auto-generated method stub
		if(!isProvider()){
			System.out.println("no send queue provided ");
		}else{
			System.out.println("calling sendJms method...");
	        sendJms(message);
		}
    }
	
	public Vector getBroadcastStatus() {
		// TODO Auto-generated method stub
		if(!isConsumer()){
			System.out.println("no recieve queue provided ");
		}
		return messages;
	}
	public void setConnectionFactory(ConnectionFactory connectionFactory) {
		this.connectionFactory = connectionFactory;
	}
	public void setResultQueue(Destination resultQueue) {
		this.resultQueue = resultQueue;
	}
	public void setSendQueue(Destination sendQueue) {
		this.sendQueue = sendQueue;
	}
	
}
