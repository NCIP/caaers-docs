package gov.nih.nci.cabig.caaers.service;

import gov.nih.nci.cabig.caaers.domain.report.Report;

public class SchedulerServiceStub implements SchedulerService {

    public void scheduleNotification(Report report) {
        // TODO Auto-generated method stub

    }

    public void unScheduleNotification(Report report) {
        // TODO Auto-generated method stub

    }

}
