package gov.nih.nci.cabig.caaers.rules.deploy;

public class MiscObject {
    public boolean validate(Object o) {
        return true;
    }
}
