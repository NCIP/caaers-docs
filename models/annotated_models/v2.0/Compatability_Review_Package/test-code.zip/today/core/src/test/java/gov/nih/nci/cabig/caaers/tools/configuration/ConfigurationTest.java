package gov.nih.nci.cabig.caaers.tools.configuration;

import gov.nih.nci.cabig.caaers.CaaersTestCase;
/**
 * 
 * @author Biju Joseph
 *
 */
public class ConfigurationTest extends CaaersTestCase {
	Configuration configuration;
	protected void setUp() throws Exception {
		super.setUp();
		configuration = (Configuration) getDeployedApplicationContext().getBean("configuration");
	}
	
	public void testLoad(){
		assertNotNull(Configuration.LAST_LOADED_CONFIGURATION);
	}
	
	public void testGetProperties() {
		assertNotNull(configuration.get(Configuration.UNIDENTIFIED_MODE));
	}

}
