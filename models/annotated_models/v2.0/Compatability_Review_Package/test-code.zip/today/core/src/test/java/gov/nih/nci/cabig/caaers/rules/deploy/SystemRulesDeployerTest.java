package gov.nih.nci.cabig.caaers.rules.deploy;

import junit.framework.TestCase;

public class SystemRulesDeployerTest extends TestCase {

    protected void setUp() throws Exception {
        super.setUp();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testSystemRulesDeployer() throws Exception {
    }
}
