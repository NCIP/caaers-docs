package gov.nih.nci.cabig.caaers.rules.adapter;

import gov.nih.nci.cabig.caaers.rules.v1_0.RuleSet;

public interface RuleAdapter {

	public Object adapt(RuleSet ruleSet);

}
