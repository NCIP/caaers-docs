package gov.nih.nci.cabig.caaers.rules.adapter;

public class JBossReflectiveVisitorAdapter {

}
