// Namespace for caAERS-specific shared functions and classes
var AE = { }