package gov.nih.nci.cabig.caaers.domain;

public interface StudySiteChild {
	public void setStudySite(StudySite ss);
	public StudySite getStudySite();
}
