package gov.nih.nci.cabig.caaers.domain;

/**
 * @author Rhett Sutphin
 */
public interface RoutineAdverseEventReportChild {
    void setRoutineReport(RoutineAdverseEventReport report);
    RoutineAdverseEventReport getRoutineReport();
}
