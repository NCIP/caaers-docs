var g_ContentsURL = "caaersSource_Full-toc.htm";
var g_IndexURL = "caaersSource_Full-index.htm";
var g_SearchURL = "caaersSource_Full-search.htm";
var g_FavoritesURL = "caaersSource_Full-favorites.htm";
