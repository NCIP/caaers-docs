#!/bin/bash

mvn install:install-file \
	-DgroupId=gov.nih.nci.security \
	-DartifactId=csm \
	-Dversion=pre3.2 \
	-Dpackaging=jar \
	-Dfile=csm/csmapi-pre3.2.jar
	
mvn install:install-file \
	-DgroupId=gov.nih.nci.security \
	-DartifactId=clm \
	-Dversion=pre3.2 \
	-Dpackaging=jar \
	-Dfile=clm/clm-pre3.2.jar	
	
