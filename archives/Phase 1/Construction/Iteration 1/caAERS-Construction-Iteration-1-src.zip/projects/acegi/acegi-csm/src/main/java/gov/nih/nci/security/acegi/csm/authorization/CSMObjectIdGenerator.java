package gov.nih.nci.security.acegi.csm.authorization;

public interface CSMObjectIdGenerator {

	String generateId(Object object);
	
}
