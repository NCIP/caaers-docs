package gov.nih.nci.cabig.caaers.domain;

/**
 * @author Rhett Sutphin
 */
public interface CodedEnum {
    int getCode();
    String getDisplayName();
}
