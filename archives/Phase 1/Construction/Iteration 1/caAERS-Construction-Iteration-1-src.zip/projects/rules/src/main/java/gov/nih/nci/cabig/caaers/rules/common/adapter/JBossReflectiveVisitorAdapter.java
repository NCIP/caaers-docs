package gov.nih.nci.cabig.caaers.rules.common.adapter;

public class JBossReflectiveVisitorAdapter {

}
