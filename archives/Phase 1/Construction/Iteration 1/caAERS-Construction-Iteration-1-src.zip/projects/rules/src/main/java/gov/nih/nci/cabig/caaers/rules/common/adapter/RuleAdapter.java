package gov.nih.nci.cabig.caaers.rules.common.adapter;

import gov.nih.nci.cabig.caaers.rules.brxml.RuleSet;

public interface RuleAdapter {

	public Object adapt(RuleSet ruleSet);

}
