/**
 * 
 */
package gov.nih.nci.security.acegi.grid.authentication;

/**
 * @author <a href="mailto:joshua.phillips@semanticbits.com>Joshua Phillips</a>
 * 
 */
public class AuthenticationErrorException extends Exception {

  /**
   * 
   */
  public AuthenticationErrorException() {
    // TODO Auto-generated constructor stub
  }

  /**
   * @param arg0
   */
  public AuthenticationErrorException(String arg0) {
    super(arg0);
    // TODO Auto-generated constructor stub
  }

  /**
   * @param arg0
   */
  public AuthenticationErrorException(Throwable arg0) {
    super(arg0);
    // TODO Auto-generated constructor stub
  }

  /**
   * @param arg0
   * @param arg1
   */
  public AuthenticationErrorException(String arg0, Throwable arg1) {
    super(arg0, arg1);
    // TODO Auto-generated constructor stub
  }

}
