package gov.nih.nci.security.acegi.acls.test;

public class SomeBean {

}
