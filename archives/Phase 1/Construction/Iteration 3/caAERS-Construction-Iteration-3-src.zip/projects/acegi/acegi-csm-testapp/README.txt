The unit tests require MySQL. Create database named "testapp" and user
named "testapp" with password "testapp". You can modify 
src/test/resources/hibernate.properties directly if you like.