Modifications:

src/gov/nih/nci/security/provisioning/UserProvisioningManagerImpl.java
 - Added default constructor to allow extension.