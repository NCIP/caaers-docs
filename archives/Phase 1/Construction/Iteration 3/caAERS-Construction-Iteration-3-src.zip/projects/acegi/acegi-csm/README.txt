Befor compiling this module, the CSM and CLM dependencies must
be installed in your local repository. To do this:

cd toinstall
./install.sh

