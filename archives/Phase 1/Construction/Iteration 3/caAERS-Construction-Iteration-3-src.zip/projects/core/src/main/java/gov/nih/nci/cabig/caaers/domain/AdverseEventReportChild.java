package gov.nih.nci.cabig.caaers.domain;

/**
 * @author Rhett Sutphin
 */
public interface AdverseEventReportChild {
    void setReport(AdverseEventReport report);
    AdverseEventReport getReport();
}
