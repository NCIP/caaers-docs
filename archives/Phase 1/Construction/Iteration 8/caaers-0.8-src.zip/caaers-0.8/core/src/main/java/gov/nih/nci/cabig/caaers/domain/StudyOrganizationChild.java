package gov.nih.nci.cabig.caaers.domain;

public interface StudyOrganizationChild {
	public void setStudyOrganization(StudyOrganization studyOrg);
	public StudyOrganization getStudyOrganization();
}
