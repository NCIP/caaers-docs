package gov.nih.nci.cabig.caaers.domain;

public interface StudyAgentChild {
	public void setStudyAgent(StudyAgent agent);
	public StudyAgent getStudyAgent();
}
