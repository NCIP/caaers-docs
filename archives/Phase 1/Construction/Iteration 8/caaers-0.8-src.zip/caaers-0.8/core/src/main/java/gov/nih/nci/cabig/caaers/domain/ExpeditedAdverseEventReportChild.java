package gov.nih.nci.cabig.caaers.domain;

/**
 * @author Rhett Sutphin
 */
public interface ExpeditedAdverseEventReportChild {
    void setReport(ExpeditedAdverseEventReport report);
    ExpeditedAdverseEventReport getReport();
}
