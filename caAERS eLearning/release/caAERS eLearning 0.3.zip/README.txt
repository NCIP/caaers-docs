To run caAERS eLearning, simply open index.html by double-clicking it.

To install caAERS eLearning into a web server, read INSTALLATION.txt.